// Test 04 – Diáknap 2026
// Do not change the data below.

const programs = [
  { title: "Focikupa", place: "Tornaterem", time: "9:00", type: "sport" },
  { title: "Karaoke", place: "Aula", time: "10:30", type: "zene" },
  { title: "Társasjáték-sarok", place: "Könyvtár", time: "11:00", type: "játék" },
  { title: "Kosárdobó verseny", place: "Udvar", time: "12:00", type: "sport" },
  { title: "Tanárzenekar", place: "Aula", time: "13:30", type: "zene" },
  { title: "Kahoot-bajnokság", place: "Informatika terem", time: "14:00", type: "játék" }
];

const workshop = { name: "Robotépítő műhely", seats: 3 };

// Write your code below this line.
