// Lesson 8: your own server.
// Start it:  node server.js
// Stop it:   Ctrl+C in this terminal
const express = require("express");
const app = express();

// The time the server started. It changes every time you start it again.
const startedAt = new Date().toLocaleTimeString("hu-HU");

app.get("/health", (req, res) => {
  res.json({ status: "ok", owner: "nobody", startedAt: startedAt });
});

app.listen(3000, () => {
  console.log("Listening on http://localhost:3000");
  console.log("Ask it: http://localhost:3000/health");
});
