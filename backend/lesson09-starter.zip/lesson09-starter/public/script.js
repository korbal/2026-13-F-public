// This page asks your server for your list and puts it in a table.
document.querySelector("#origin").textContent = "This page came from: " + location.href;

async function load() {
  // Task 2: write the address of your list between the quotes, for example "/games".
  const response = await fetch("");
  const items = await response.json();
  console.log(items);

  // One column for each field of the first item.
  const fields = Object.keys(items[0]);
  const headRow = document.createElement("tr");
  for (const field of fields) {
    const th = document.createElement("th");
    th.textContent = field;
    headRow.appendChild(th);
  }
  document.querySelector("#list-head").appendChild(headRow);

  // One row for each item.
  for (let i = 0; i < items.length; i++) {
    const row = document.createElement("tr");
    for (const field of fields) {
      const td = document.createElement("td");
      td.textContent = items[i][field];
      row.appendChild(td);
    }
    document.querySelector("#list-rows").appendChild(row);
  }
}

load().catch(function (error) {
  document.querySelector("#msg").textContent = "Couldn't load the list: " + error.message;
  console.error(error);
});
