// Lesson 9: your server, your data.
// Start it:  node server.js
// Stop it:   Ctrl+C in this terminal
const express = require("express");
const app = express();

// localhost:3000/ shows the page in the public folder.
app.use(express.static("public"));

// Task 1: your list goes here.


app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.listen(3000, () => {
  console.log("Listening on http://localhost:3000");
});
