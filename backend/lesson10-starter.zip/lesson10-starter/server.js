// Lesson 10: one by id.
// Start it:  node --watch server.js   (or node server.js)
// Stop it:   Ctrl+C in this terminal
const express = require("express");
const app = express();

// localhost:3000/ shows the page in the public folder.
app.use(express.static("public"));

const cats = [
  { id: 1, name: "Cirmi", age: 3, hobby: "sleeping" },
  { id: 2, name: "Mázli", age: 1, hobby: "boxes" },
  { id: 3, name: "Bajusz", age: 7, hobby: "birds" },
  { id: 4, name: "Pamacs", age: 2, hobby: "string" }
];

const owners = [
  { id: 1, name: "Anna", city: "Győr" },
  { id: 2, name: "Bence", city: "Pápa" },
  { id: 3, name: "Csilla", city: "Mosonmagyaróvár" }
];

// The whole list.
app.get("/cats", (req, res) => {
  res.json(cats);
});

// Task 1: one cat, by its id.


app.listen(3000, () => {
  console.log("Listening on http://localhost:3000");
});
