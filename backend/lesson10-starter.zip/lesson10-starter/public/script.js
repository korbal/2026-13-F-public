// Extra A: when Find is pressed, ask your server for one cat and show it in #card.
// If the server says 404, show "Not found" instead.
document.querySelector("#find").addEventListener("click", async function () {
  const id = document.querySelector("#cat-id").value;
  const card = document.querySelector("#card");

  // Your code here.

});
